<?php
 
	include_once("includes/database.php");
 
	$id = $_GET['id'];

	$lat = 0;
	$long = 0;
	$zoom = 8;

	$findmap = "SELECT centerLat, centerLong, zoom FROM maps WHERE ID = $id";

	if(!$result = $conexion->query($findmap)){
		die('There was an error running the query [' . $conexion->error . ']');
	} else {
		$row = $result->fetch_assoc();
		$lat = $row['centerLat'];
		$long = $row['centerLong'];
		$zoom = $row['zoom'];
	}   
 
?>

<!DOCTYPE html>
<html class="no-js">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Tasters</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css">
	<link href='http://fonts.googleapis.com/css?family=Dosis:400,200,300,500,600' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Lato:400,100,300,700' rel='stylesheet' type='text/css'>
	<link rel="shortcut icon" href="favicon.ico" />

	<script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>

	<script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js">
    </script>
    <script type="text/javascript">
      function initialize() {
        var mapOptions = {
          center: new google.maps.LatLng(<?php echo $lat.', '.$long; ?>),
          zoom: <?php echo $zoom; ?>
        };
        var map = new google.maps.Map(document.getElementById("map-canvas"),
            mapOptions);
		    <?php
			  $getpoints = "SELECT pointLat, pointLong, pointText 
			      FROM mappoints WHERE mapID = $id";
			 
			  if(!$result = $conexion->query($getpoints)){
			    die('There was an error running the query 
			        [' . $conexion->error . ']');
			  } else {
			    while ($row = $result->fetch_assoc()) {
			      echo '  var myLatlng1 = new google.maps.LatLng('.
			          $row['pointLat'].', '.$row['pointLong'].'); 
			  var marker1 = new google.maps.Marker({ 
			    position: myLatlng1, 
			    map: map, 
			    title:"'.$row['pointText'].'"
			  });';
			    }
			  }
			?>
      }
      google.maps.event.addDomListener(window, 'load', initialize);
    </script>



</head>
<body>

	<div class="container-full">
		<img src="img/fondos/img8.jpg" alt="comida1"/>
	</div>

	<div class="container">
		<div class="info col-lg-2 col-md-2 col-sm-2 col-xs-2">
			<img src="img/tasterHeader.png" alt="taster"/>
		</div>
		<div class="infoNivel col-lg-10 col-md-10 col-sm-10 col-xs-10">
			<img src="img/nivel.png" alt="taster"/>
		</div>
	</div>

	<div class="container">
		<div class="imagenUsuario col-lg-2 col-md-2 col-sm-3 col-xs-3">
			<figure>
				<img src="img/usuarios/Ures.jpg" alt="user1"/>
			</figure>
		</div>

		<div class="nombreUsuario col-lg-2 col-md-2 col-sm-3 col-xs-3">
			<p>ITALIANO </p>
			<p>LA CASONA</p>

			<a href="">
				<div class="seguir col-lg-8 col-md-10 col-sm-8 col-xs-8">
					<p>Seguir</p>
					<img src="img/T-seguir.png" alt="T" width="15" />				
				</div>
			</a>
		</div>

		<div class="lugarFavorito col-lg-2 col-md-8 col-sm-6 col-xs-6">
			<!-- <p>EL PEÑÓN</p>
			<p id="lugar">LUGAR FAVORITO</p> -->
		</div>	
	</div>

	<div class="container">
		<div class="barraNavegacion col-lg-2 col-md-4 col-sm-12 col-xs-12">
			<hr> 
			<nav>
				<ul>
					<a href="">
						<li>
							<p>+</p>
						</li>
					</a>
					<a href="">
						<li>
							<p>PUBLICACIONES</p>
						</li>
					</a>
					<a class="especial" href="">
						<li>
							<p>TASTES</p>
						</li>
					</a>
					<a class="especial" href="">
						<li>
							<p>SEGUIDORES</p>
						</li>
					</a>
					<a class="especial" href="">
						<li>
							<p>SIGUIENDO A</p>
						</li>
					</a>
				</ul>
			</nav>
			<div id="map-canvas" style="height: 400px" />
		</div>
	</div>

	<section>
		<div class="containerDos">
			<article class = "articulo col-lg-6 col-md-10 col-sm-11 col-xs-11">
				<figure class="col-lg-3 col-md-3 col-sm-3 col-xs-4">
					<img src="img/usuarios/res.jpg"  alt="msn"/>	
				</figure>

<div class="col-lg-4 col-md-3 col-sm-5 col-xs-5">						
					
				<h4>ITALIANO</h4>
				<h4>LA CASONA</h4>
				<p>Hace 8 minutos</p>
				<a href="">
</div>
				<!-- <div class="seguirUsuario col-lg-4 col-md-3 col-sm-3 col-xs-4">
						<p>Seguir</p>
						<img src="img/T-seguir.png" alt="T" width="15" />				
					</div> -->
       
                  <figure class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<img src="img/fondos/post.jpg"  alt="msn"/>	
				</figure>

				</a>

          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h4>SALERNO</h4>
					<p> Nuevo plato, el preferido de todos. ¡Venga y pruébelo!</p>	
<div class="icon col-lg-12 col-md-12 col-sm-12 col-xs-12">

        <img src="img/T-seguir.png" alt="T" width="15" />
<p> 2 tastes</p>
</div>

<figure class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
					<img src="img/usuarios/icon.jpg"  alt="msn" height="100"  />	
				</figure>

				 <input type="text" class="form-control inputfiltro datosUsuario" name="" placeholder="Escribe un comentario">
    </input>

</div>
</article>

			

		</div> <!-- /container -->
	</section>

	<div class="container">
		<div class="footer col-lg-3 col-md-4 col-sm-6 col-xs-6">
			<hr noshade>
			<footer>
				<p>
					<a href="#">Acerca de</a> |
					<a href="#">Términos y Condiciones</a> |
					<a href="#">Contacto</a>
				</p>
				<p>&copy; 2014</p>
				<div class="footerDos col-lg-4 col-md-5 col-sm-4 col-xs-4">
					<footer>
						<img src="img/tasterFooter.png" alt="taster"/>
					</footer>
				</div>
			</footer>
		</div>
		<div class="footerTres col-lg-4 col-md-2 col-sm-2 col-xs-2"
			<footer>
				<img src="img/tasterFooter.png" alt="taster"/>
			</footer>
		</div>
	</div>
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.1.min.js"><\/script>')</script>

	<script src="js/vendor/bootstrap.min.js"></script>

	<script src="js/main.js"></script>

</body>
</html>