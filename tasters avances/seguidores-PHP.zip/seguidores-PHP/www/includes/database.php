<?php

	$host = "localhost";
	$user = "root";
	$clave = "";

	$conexion = mysqli_connect($host, $user, $clave, "tasters_basededatos") or die("Error en la conexión con la base de datos");
	//echo "Base de datos conectada satisfactoriamente.";

?>