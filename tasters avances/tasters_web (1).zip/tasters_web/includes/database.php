<?php
$host ="localhost";
$root ="root";
$pass ="";
$db ="tasters_basededatos";

$con=mysqli_connect($host,$root,$pass,$db) or die("Unable to connect to $host");


?>